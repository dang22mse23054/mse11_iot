from keras.models import load_model  # TensorFlow is required for Keras to work
import cv2  # Install opencv-python
import numpy as np
import sys
import random
import time
from datetime import datetime
import base64

from Adafruit_IO import MQTTClient


AIO_FEED_ID = [
	# "cambien1",
	# "cambien2",
	# "cambien3",
	# "nutnhan1",
	# "nutnhan2",
	"cambien3",
]
AIO_USERNAME = "HienNTM"
AIO_KEY = "aio_BQUB10yvpNMYWjX00doNmeCBmtBc"


def connected(client):
	print("Ket noi thanh cong ...")
	for topic in AIO_FEED_ID:
		client.subscribe(topic)


def subscribe(client, userdata, mid, granted_qos):
	print("Subscribe thanh cong ...")


def disconnected(client):
	print("Ngat ket noi ...")
	sys.exit(1)


def message(client, feed_id, payload):
	print("Nhan du lieu: " + payload)
	

client = MQTTClient(AIO_USERNAME, AIO_KEY)
client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message
client.on_subscribe = subscribe
client.connect()
client.loop_background()



# Disable scientific notation for clarity
np.set_printoptions(suppress=True)

# Load the model
# model = load_model("keras_Model.h5", compile=False)
model = load_model("has_mask.h5", compile=False)

# Load the labels
class_names = open("labels.txt", "r").readlines()

# CAMERA can be 0 or 1 based on default camera of your computer
camera = cv2.VideoCapture(0)

while True:
    # Grab the webcamera's image.
    ret, image = camera.read()

    # Resize the raw image into (224-height,224-width) pixels
    image = cv2.resize(image, (224, 224), interpolation=cv2.INTER_AREA)
    
    res, frame = cv2.imencode('.jpg', image)
    imgBs64 = base64.b64encode(frame)
    # print(imgBs64)

    # Show the image in a window
    cv2.imshow("Webcam Image", image)

    # Make the image a numpy array and reshape it to the models input shape.
    image = np.asarray(image, dtype=np.float32).reshape(1, 224, 224, 3)

    # Normalize the image array
    image = (image / 127.5) - 1

    # Predicts the model
    prediction = model.predict(image)
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]


    # time.sleep(3)
    time.sleep(3)

    # Print prediction and confidence score
    print("Class:", class_name[2:], end="")
    print("Confidence Score:", str(np.round(confidence_score * 100))[:-2], "%") 
    client.publish("cambien3", class_name[2:] )

    # Listen to the keyboard for presses.
    keyboard_input = cv2.waitKey(1)

    # 27 is the ASCII for the esc key on your keyboard.
    if keyboard_input == 27:
        break

camera.release()
cv2.destroyAllWindows()
